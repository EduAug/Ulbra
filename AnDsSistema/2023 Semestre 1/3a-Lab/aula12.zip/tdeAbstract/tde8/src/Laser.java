public class Laser extends Impressora{

    @Override
    public String imprimir(){

        return "Laser-eado em papel com sucesso";
    }

    @Override
    public String escanear(){

        return "Fotocópia salva no disco X";
    }
}
