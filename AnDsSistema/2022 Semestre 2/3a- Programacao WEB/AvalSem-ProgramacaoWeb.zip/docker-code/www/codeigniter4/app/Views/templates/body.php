            </section>
        </div>
               
            <nav class="col-md-3 bg-secondary2 text-center p-3">
                <h2>Menu:</h2>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a id="menHo" class="nav-link" href="<?=base_url('home')?>">Home</a>
                    </li>
                    <li class="nav-item">
                        <a id="menAb" class="nav-link" href="<?=base_url('about')?>">About</a>
                    </li>
                    <li class="nav-item">
                        <a id="menPr" class="nav-link" href="<?=base_url('products')?>">Classifieds</a>
                    </li>
                    <li class="nav-item">
                        <a id="menCo" class="nav-link" href="<?=base_url('contact')?>">Contact</a>
                    </li>
                </ul>
                <h2>Readers:</h2>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="<?=base_url('listClients')?>">Readers' Club</a>
                    </li>
                </ul>

            </nav>
            

    </div>
</div>