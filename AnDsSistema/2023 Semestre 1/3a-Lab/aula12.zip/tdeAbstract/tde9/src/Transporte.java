public abstract class Transporte{

    public abstract double carregar();

    public abstract double descarregar();
}
