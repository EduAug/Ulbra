public class Main {
    public static void main(String[] args){

        String[] cores = {"vermelho", "azul", "verde", "amarelo", "roxo"};

        for(int i = cores.length-1; i >= 0; i--){
            System.out.println(cores[i]);
        }
    }
}