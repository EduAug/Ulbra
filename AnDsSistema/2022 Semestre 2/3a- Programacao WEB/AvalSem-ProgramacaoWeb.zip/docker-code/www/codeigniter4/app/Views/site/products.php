<div class="container-fluid">
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-8 border-custom2">
            <section>

                <h1 class="fw-bold text-center pt-2">The hottest products near you</h1>
                <hr>
                

                <div class="container p-3">
                    <div class="row mb-2">
                        <div class="col-4">
                            <div class="card" style="width:200px">
                                <img class="card-img-top" src="https://www.w3schools.com/bootstrap5/sanfran.jpg" alt="Card image">
                                <div class="card-body text-center">
                                    <h4 class="card-title">Golden Gate</h4>
                                    <p class="card-text">$xx,xxx,xxx.xx</p>
                                    <a href="#" class="btn btn-custom">Buy</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card" style="width:200px">
                                <img class="card-img-top" src="https://www.w3schools.com/bootstrap5/sanfran.jpg" alt="Card image">
                                <div class="card-body text-center">
                                    <h4 class="card-title">Golden Gate Picture</h4>
                                    <p class="card-text">$x.xx</p>
                                    <a href="#" class="btn btn-custom">Buy</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card" style="width:200px">
                                <img class="card-img-top" src="https://www.w3schools.com/bootstrap5/sanfran.jpg" alt="Card image">
                                <div class="card-body text-center">
                                    <h4 class="card-title">Golden Gate Cushion</h4>
                                    <p class="card-text">$xx.xx</p>
                                    <a href="#" class="btn btn-custom">Buy</a>
                                </div>
                            </div>
                        </div>
                    </div>
<hr>
                    <div class="row mt-2">
                        <div class="col-4">
                            <div class="card" style="width:200px">
                                <img class="card-img-top" src="https://www.w3schools.com/bootstrap5/sanfran.jpg" alt="Card image">
                                <div class="card-body text-center">
                                    <h4 class="card-title">Classified4</h4>
                                    <p class="card-text">$xx.xx</p>
                                    <a href="#" class="btn btn-custom">Buy</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card" style="width:200px">
                                <img class="card-img-top" src="https://www.w3schools.com/bootstrap5/sanfran.jpg" alt="Card image">
                                <div class="card-body text-center">
                                    <h4 class="card-title">Classified5</h4>
                                    <p class="card-text">$xx.xx</p>
                                    <a href="#" class="btn btn-custom">Buy</a>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card" style="width:200px">
                                <img class="card-img-top" src="https://www.w3schools.com/bootstrap5/sanfran.jpg" alt="Card image">
                                <div class="card-body text-center">
                                    <h4 class="card-title">Classified6</h4>
                                    <p class="card-text">$xx.xx</p>
                                    <a href="#" class="btn btn-custom">Buy</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
