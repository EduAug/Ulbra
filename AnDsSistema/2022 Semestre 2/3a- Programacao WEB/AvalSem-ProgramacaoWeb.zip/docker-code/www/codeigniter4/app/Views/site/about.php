<div class="container-fluid">
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-8 border-custom2">
            <section>

                <h1 class="fw-bold text-center">"Who is 'PLACEHOLDER News'"?!</h1>
                <p>Starting off an old garage with nothing but a dream, paper and ink, adipisicing elit. Molestiae corporis reprehenderit officiis nihil soluta doloremque labore magnam eius unde aspernatur repudiandae quis sunt sed, libero deleniti eum suscipit, harum, maxime tenetur qui nulla odit veritatis.</p>
                <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Quae, beatae? Maiores blanditiis in harum iure quisquam sapiente, accusantium ab sequi necessitatibus iusto quam rem, tenetur numquam est neque cupiditate consequuntur tempora corrupti voluptatum, a ducimus! Quod odit nobis reprehenderit. Quam voluptatum nostrum modi qui vitae tempore atque, inventore facilis tenetur cupiditate? Eaque praesentium placeat id repudiandae veniam, accusamus nam facere, vel laborum alias adipisci consectetur a consequatur cumque beatae ea ducimus ut aspernatur, dicta rerum. Nulla consequuntur deleniti ut earum error nesciunt veritatis possimus voluptas id. Reprehenderit possimus quam, doloribus nobis saepe, ullam totam animi error laboriosam natus nesciunt ea at facilis repudiandae expedita corrupti aut id. Sit ex, omnis eligendi sunt necessitatibus quibusdam deserunt, commodi, praesentium temporibus fugit adipisci!
                </p>
                <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Aliquam et laborum facilis?</p>