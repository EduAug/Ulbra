public class Caminhao extends Transporte{

    @Override
    public double carregar(){

        return 100;
    }

    @Override
    public double descarregar(){

        return 99.8;
    }
}
