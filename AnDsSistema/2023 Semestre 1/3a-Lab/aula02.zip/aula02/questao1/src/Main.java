public class Main {
    public static void main(String[] args) {

        double n1=8.5;
        double n2=7.5;
        double n3=6.0;

        int p1=3;
        int p2=2;
        int p3=5;

        double nf1 = n1*p1;
        double nf2 = n2*p2;
        double nf3 = n3*p3;

        double varmedia = (nf1+nf2+nf3)/(p1+p2+p3);
        System.out.println("A média final do aluno é "+varmedia);


    }
}