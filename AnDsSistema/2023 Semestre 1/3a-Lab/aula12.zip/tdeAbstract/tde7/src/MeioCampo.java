public class MeioCampo extends Jogador{

    @Override
    public String atacar(){

        return "Passou do meio de campo";
    }

    @Override
    public String defender() {

        return "Voltou do meio do campo";
    }
}
