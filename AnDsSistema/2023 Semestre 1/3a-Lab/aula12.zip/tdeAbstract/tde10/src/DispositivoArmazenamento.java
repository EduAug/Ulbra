public abstract class DispositivoArmazenamento{

    public abstract String lerDados();

    public abstract void gravarDados(String data);
}
