<div class="container-fluid">
    <div class="row">
            <nav class="col-md-3 bg-secondary2 text-center p-3">
                <h2>Menu</h2>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="<?=base_url('/admin')?>">Navigate</a>
                    </li>
                </ul>
                <h2>Clients(Readers)</h2>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="<?=base_url('/admin/listClients')?>">List Clients</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="<?=base_url('/admin/insertClient')?>">Add Client</a>
                    </li>
                </ul>

            </nav>
