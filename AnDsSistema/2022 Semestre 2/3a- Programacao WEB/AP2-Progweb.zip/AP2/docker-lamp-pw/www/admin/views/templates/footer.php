<footer>
    <div class="container-fluid text-center p-2">
        <h4>Copyright © Lorem, ipsum.com</h4>
            <a class="text-decoration-none h5" href="../index.php">Site</a>
    </div>
</footer>