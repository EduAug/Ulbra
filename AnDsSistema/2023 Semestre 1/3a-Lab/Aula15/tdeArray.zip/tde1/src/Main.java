public class Main {
    public static void main(String[] args){

        int[] numeros = {1,2,3,4,5};

        for(int i = numeros[0]-1; i < numeros.length; i++){

            System.out.println("Numero "+i+" : "+numeros[i]);
        }
    }
}