<?php

    class ClientController{
        public function register(){
            require_once('views/templates/header.php');
            require_once('views/templates/body.php');
            require_once('views/client/register.php');
            require_once('views/templates/footer.php');
        }
    }

?>