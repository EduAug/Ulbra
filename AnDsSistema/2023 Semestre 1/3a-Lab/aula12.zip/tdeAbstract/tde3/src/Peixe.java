public class Peixe extends Animal{

    @Override
    public void andar(){

        System.out.println("Peixe nada^");
    }

    @Override
    public void comer(){

        System.out.println("Peixe come^");
    }

    @Override
    public void dormir(){

        System.out.println("Peixe dorme^");
    }
}
