<h1 class="fw-bold text-center">Sobre!</h1>
<p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Molestiae corporis reprehenderit officiis nihil soluta doloremque labore magnam eius unde aspernatur repudiandae quis sunt sed, libero deleniti eum suscipit, harum, maxime tenetur qui nulla odit veritatis.</p>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Sapiente ex minus fuga nihil, temporibus iste delectus nisi commodi aut facilis perspiciatis, accusantium inventore numquam at tempora.</p>
<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit.</p>