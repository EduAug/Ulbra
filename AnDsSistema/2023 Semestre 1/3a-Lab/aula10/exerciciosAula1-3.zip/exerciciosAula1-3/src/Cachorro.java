public class Cachorro {

    String nome;
    String raca;
    int idade;

    public Cachorro(String _nome, String _raca){

        this.nome = _nome;
        this.raca = _raca;
        this.idade = 3;
    }
}
