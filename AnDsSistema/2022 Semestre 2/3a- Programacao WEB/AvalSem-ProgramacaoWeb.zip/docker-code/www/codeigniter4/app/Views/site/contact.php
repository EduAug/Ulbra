<div class="container-fluid">
    <div class="row">
        <div class="col-md-1"></div>
        <div class="col-md-8 border-custom2">
            <section>
                <h1 class="fw-bold text-center mt-2">Give us a call!</h1>
                    <p class="text-center">Lorem ipsum dolor sit amet consectetur adipisicing elit. Repudiandae, recusandae iste quae iure asperiores alias?</p>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-6">
                                <form class="pb-3">
                                    <div class="mb-3 mt-3">
                                        <label for="email" class="form-label">Name:</label>
                                        <input type="email" class="form-control" placeholder="Your Name">
                                    </div>
                                    <div class="mb-3">
                                        <label for="pwd" class="form-label">e-Mail Address:</label>
                                        <input type="email" class="form-control" placeholder="Your e-Mail">
                                    </div>

                                    <label for="comment">Spill the beans:</label>
                                    <textarea class="form-control" rows="5" id="comment" name="text" placeholder="Your message"></textarea>

                                    <br>
                                    <button type="submit" class="btn btn-custom">Send!</button>
                                </form>
                            </div>
                        </div>
                    </div>
