public class Matricial extends Impressora{

    @Override
    public String imprimir(){

        return "Etiqueta pronta";
    }

    @Override
    public String escanear(){

        return "ERRO";
    }
}
