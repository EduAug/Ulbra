    <h1 class='fw-bold text-center'>Cadastro de cliente</h1>

    <form action="welcome.php" method="post">
    Name: <input type="text" name="name"><br>
    E-mail: <input type="text" name="email"><br>
    <input type="submit">
    </form>

</section>
        </div>
    </div>
</div>