public abstract class Jogador{

    public abstract String atacar();
    public abstract String defender();
}
