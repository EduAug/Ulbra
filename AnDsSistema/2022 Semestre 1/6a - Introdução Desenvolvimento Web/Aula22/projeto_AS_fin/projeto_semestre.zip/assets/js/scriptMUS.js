$(document).ready(()=>{

    $("#menuStore").click(()=>{
        $("section").load("../pages/store.html");
        console.log('nao foi');
    });
});