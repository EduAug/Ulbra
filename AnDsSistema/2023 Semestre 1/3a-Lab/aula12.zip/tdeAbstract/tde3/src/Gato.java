public class Gato extends Animal{

    @Override
    public void andar(){

        System.out.println("Gato anda-");
    }

    @Override
    public void comer(){

        System.out.println("Gato come-");
    }

    @Override
    public void dormir(){

        System.out.println("Gato dorme-");
    }
}
