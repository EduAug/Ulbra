    <footer>
        <div class="container-fluid text-center p-2">
            <h4>Copyright © placeholderNews.com</h4>
                <a class="h5" href="<?=base_url('/admin')?>">Admin Area</a>
        </div>
    </footer>

</html>