public abstract class Arquivo{

    public abstract String abrir();

    public abstract String fechar();
}
