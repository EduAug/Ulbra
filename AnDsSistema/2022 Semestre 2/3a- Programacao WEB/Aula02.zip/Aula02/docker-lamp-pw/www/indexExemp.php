<!-- <?php
    $var = 'exemplo';
    echo 'Isso é um'.' '.$var; 
?> -->

  
<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        echo '<h1>Minha página PHP</h1>';
        $var1=1;
        var_dump($var1);
        $var1='1';
        var_dump($var1);
        $var2=1;
        if(isset($var2)){
            echo 'Minha variável var2'.' (' .$var2. ') '. 'está setada';
        }else{
            echo 'Minha variável var2'.' (' .$var2. ') '. 'não está setada';
        }
    ?>
</body>
</html> -->

<!-- <?php

    for ($x=0; $x <= 10; $x++) { 
        echo "O número é $x\n";
    }

?> -->