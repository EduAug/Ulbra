alter table fornecedores 
    modify column nome varchar(50);