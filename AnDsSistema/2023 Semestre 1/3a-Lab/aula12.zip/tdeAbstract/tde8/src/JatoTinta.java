public class JatoTinta extends Impressora{

    @Override
    public String imprimir(){

        return "I M P R E S S O - Tinta utilizada 0.2ml";
    }

    @Override
    public String escanear(){

        return "Escaneado e salvo no computador X";
    }
}
