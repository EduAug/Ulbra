<div class="container-fluid">
    <div class="row">
            <nav class="col-md-3 p-3">
                <h2>Menu:</h2>
                <ul class="nav flex-column">
                    <li class="nav-item">
                                            <!--mudar controller para site-->
                        <a class="nav-link" href="?controller=main&action=home">Home</a>
                    </li>
                </ul>
                <h2>Clientes</h2>
                <ul class="nav flex-column">
                    <li class="nav-item">
                                            <!--mudar controller para site-->
                        <a class="nav-link" href="?controller=client&action=listClients">Listar Clientes</a>
                    </li>
                </ul>

            </nav>
        <div class="col-md-9">
            <section>
