public class Trem extends Transporte{

    @Override
    public double carregar(){

        return 426.12;
    }

    @Override
    public double descarregar(){

        return 426;
    }
}
