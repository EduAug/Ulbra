    <h1 class="fw-bold text-center">Contato!</h1>
    <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nobis, voluptates suscipit reiciendis iure quos optio repellat
        aut dolorem! Architecto cupiditate consectetur neque soluta quibusdam! Sapiente, maxime.</p>

    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <form class="pb-3">
                    <div class="mb-3 mt-3">
                        <label for="email" class="form-label">Nome:</label>
                        <input type="email" class="form-control" placeholder="Your Name">
                    </div>
                    <div class="mb-3">
                        <label for="pwd" class="form-label">e-Mail:</label>
                        <input type="email" class="form-control" placeholder="Your e-Mail">
                    </div>

                    <label for="comment">Comment:</label>
                    <textarea class="form-control" rows="5" id="comment" name="text"></textarea>

                    <br>
                    <button type="submit" class="btn btn-primary">Enviar!</button>
                </form>
            </div>
        </div>
    </div>


</section>
        </div>
    </div>
</div>