public class Main {
    public static void main(String[] args) {

        Carro car = new Carro();

        System.out.println(car.acelerar());
        System.out.println(car.frear());
    }
}