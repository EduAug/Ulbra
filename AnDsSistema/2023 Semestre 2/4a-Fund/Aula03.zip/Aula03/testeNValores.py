num = int("-1")
print(num)