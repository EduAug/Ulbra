<div class="container-fluid text-center text-white bg-secondary p-2">
    <h4>Copyright © Lorem, ipsum.com</h4>
        <a class="link-light text-decoration-none h5" href="<?=base_url('/admin')?>">Área aministrativa</a>
</div>