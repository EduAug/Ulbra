alter table pedidos
    add numero_do_pedido varchar(20) NOT NULL;