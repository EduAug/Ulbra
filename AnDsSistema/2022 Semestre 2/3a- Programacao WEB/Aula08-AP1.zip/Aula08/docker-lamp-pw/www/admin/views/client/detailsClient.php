<h1>Detalhes do cliente</h1>
<table class="table">
    <tr>

    <th>
        Id Cliente
    </th>
    <td>
        <?=$arrayClient['idClient']?>
    </td>

    </tr>
    <tr>

    <th>
        Nome Cliente
    </th>
    <td>
        <?=$arrayClient['name']?>
    </td>

    </tr>
    <tr>

    <th>
        E-Mail Cliente
    </th>
    <td>
        <?=$arrayClient['email']?>
    </td>

    </tr>
    <tr>

    <th>
        Telefone Cliente
    </th>
    <td>
        <?=$arrayClient['phone']?>
    </td>

    </tr>
    <tr>

    <th>
        Endereço Cliente
    </th>
    <td>
        <?=$arrayClient['address']?>
    </td>

    </tr>
</table>