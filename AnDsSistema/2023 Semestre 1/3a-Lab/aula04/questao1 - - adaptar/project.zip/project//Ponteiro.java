public class Ponteiro {
    int posicao;
}