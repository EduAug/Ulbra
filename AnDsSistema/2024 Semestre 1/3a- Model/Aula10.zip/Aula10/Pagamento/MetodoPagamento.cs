﻿public enum MetodoPagamento
{
    Dinheiro,
    CartaoCredito,
    CartaoDebito,
    Pix
}