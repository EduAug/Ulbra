<div class="container-fluid text-center text-white bg-secondary3 p-2">
    <h5>Copyright © Lorem, ipsum.com</h5>
</div>