<div class="container-fluid">              <!--Não sei se essa parte é realmente necessária-->
    <div class="row">                      <!--Mas pra previnir, deixei as navbars e etc.-->
            <nav class="col-md-3 p-3">
                <h2>Menu:</h2>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link" href="?controller=site&action=home">Home</a>
                    </li>
                </ul>

            </nav>
        <div class="col-md-9">
            <section>
