<div class="container-fluid">
    <div class="row">   
        <div class="col-md-1"></div>
        <div class="col-md-8 border-custom2">
            <section>
                <div class="home1 m-3">
                    <div class="row">
                        <div class="col-md-9">
                            <h1 class="fw-bold text-center">Home(Office)!</h1>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos natus praesentium obcaecati eos sint ipsam dolorem alias
                                    incidunt ipsum ullam aspernatur saepe, aut eaque similique quas dolorum dolores? Similique quas nemo tenetur quaerat
                                    veniam eius ab consectetur soluta eos cum!</p>
                                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Consectetur atque consequatur sit autem esse ipsum quam facilis
                                    sequi praesentium similique possimus rerum vitae numquam quos delectus nemo adipisci commodi officia voluptatem, quis
                                    vero distinctio?</p>
                                <p>Lorem ipsum dolor sit amet.</p>
                        </div>
                        <div class="col-md-3">
                            <img src="https://www.w3schools.com/html/workplace.jpg"
                             class="img-fluid m-3 
                             border border-secondary border-4 rounded"
                              width="250" height="250">
                        </div>
                    </div>
                </div>
                <hr>
                <div class="home2 m-3">
                    <div class="row">
                        <div class="col-md-9">
                            <h1 class="fw-bold text-center">Some(body)!</h1>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos natus praesentium obcaecati eos sint ipsam dolorem alias
                                    incidunt ipsum ullam aspernatur saepe, aut eaque similique quas dolorum dolores? Similique quas nemo tenetur quaerat
                                    veniam eius ab consectetur soluta eos cum!</p>
                                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Consectetur atque consequatur sit autem esse ipsum quam facilis
                                    sequi praesentium similique possimus rerum vitae numquam quos delectus nemo adipisci commodi officia voluptatem, quis
                                    vero distinctio?</p>
                                <p>Lorem ipsum dolor sit amet.</p>
                        </div>
                        <div class="col-md-3">
                            <img src="https://www.w3schools.com/html/img_girl.jpg"
                             class="img-fluid m-3
                             border border-secondary border-4 rounded" 
                             width="250" height="250">
                        </div>
                    </div>
                </div>
                <hr>
                <div class="home3 m-3">
                    <div class="row">
                        <div class="col-md-9">
                            <h1 class="fw-bold text-center">(Snow)Dome!</h1>
                                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos natus praesentium obcaecati eos sint ipsam dolorem alias
                                    incidunt ipsum ullam aspernatur saepe, aut eaque similique quas dolorum dolores? Similique quas nemo tenetur quaerat
                                    veniam eius ab consectetur soluta eos cum!</p>
                                <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Consectetur atque consequatur sit autem esse ipsum quam facilis
                                    sequi praesentium similique possimus rerum vitae numquam quos delectus nemo adipisci commodi officia voluptatem, quis
                                    vero distinctio?</p>
                                <p>Lorem ipsum dolor sit amet.</p>
                        </div>
                        <div class="col-md-3">
                            <img src="https://www.w3schools.com/css/img_lights.jpg"
                             class="img-fluid m-4 
                             border border-secondary border-4 rounded"
                              width="250" height="250">
                        </div>
                    </div>
                </div>