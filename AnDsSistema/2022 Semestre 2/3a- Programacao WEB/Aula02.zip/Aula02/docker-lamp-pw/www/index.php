    <?php
        include('assets/templates/header.php');
        include('assets/templates/body.php');
        include('assets/templates/footer.php');
    ?>