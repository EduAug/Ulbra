    <h1 class="fw-bold text-center">Produtos!</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Enim veniam qui iusto rerum cumque.</p>

    <div class="container p-3">
        <div class="row">
            <div class="col-4">
                <div class="card" style="width:200px">
                    <img class="card-img-top" src="https://www.w3schools.com/bootstrap5/sanfran.jpg" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">Produto1</h4>
                        <p class="card-text">$xx.xx</p>
                        <a href="#" class="btn btn-primary">Buy</a>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card" style="width:200px">
                    <img class="card-img-top" src="https://www.w3schools.com/bootstrap5/sanfran.jpg" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">Produto2</h4>
                        <p class="card-text">$xx.xx</p>
                        <a href="#" class="btn btn-primary">Buy</a>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="card" style="width:200px">
                    <img class="card-img-top" src="https://www.w3schools.com/bootstrap5/sanfran.jpg" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">Produto3</h4>
                        <p class="card-text">$xx.xx</p>
                        <a href="#" class="btn btn-primary">Buy</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</section>
        </div>
    </div>
</div>