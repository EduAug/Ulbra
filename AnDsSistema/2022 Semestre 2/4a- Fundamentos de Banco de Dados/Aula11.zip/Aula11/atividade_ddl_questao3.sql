alter table fornecedores
    add data_ultima_compra date NOT NULL;