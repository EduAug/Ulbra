$(document).ready(()=>{

    $("#comBuy").click(()=>{
        console.log("Ainda não há conexão com o BoaCompra, então vai pelo prompt mesmo");
    });


});