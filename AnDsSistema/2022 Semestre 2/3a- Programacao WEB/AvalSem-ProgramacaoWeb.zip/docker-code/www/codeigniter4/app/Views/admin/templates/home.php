        <div class="col-md-8">
            <section clas="border-custom2">
                    <div class="border-custom2">
                            <h1 class="fw-bold text-center">Latest news in 'home'</h1>
                            <hr>
                            <div class="home1 m-3">
                                <div class="row">
                                    <div class="col-md-9">
                                        <h1 class="fw-bold text-center">Home(Office)!</h1>
                                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos natus praesentium obcaecati eos sint ipsam dolorem alias
                                                incidunt ipsum ullam aspernatur saepe, aut eaque similique quas dolorum dolores? Similique quas nemo tenetur quaerat
                                                veniam eius ab consectetur soluta eos cum!</p>
                                            <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Consectetur atque consequatur sit autem esse ipsum quam facilis
                                                sequi praesentium similique possimus rerum vitae numquam quos delectus nemo adipisci commodi officia voluptatem, quis
                                                vero distinctio?</p>
                                            <p>Lorem ipsum dolor sit amet.</p>
                                    </div>
                                    <div class="col-md-3">
                                        <img src="https://www.w3schools.com/html/workplace.jpg"
                                        class="img-fluid m-3 
                                        border border-secondary border-4 rounded"
                                        width="250" height="250">
                                        <figcaption class="figure-caption">pc-coffe_200x200.jpg</figcaption>
                                    </div>
                                </div>
                            </div>
                    </div>    
            </section>
        </div>
        <div class="col-md-1"></div>
    </div>
</div>