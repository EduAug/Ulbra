alter table pedidos
    rename column data_hora to data_pedido;