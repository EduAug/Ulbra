public abstract class Impressora{

    public abstract String imprimir();
    public abstract String escanear();
}
