public class Navio extends Transporte{

    @Override
    public double carregar(){

        return 859;
    }

    @Override
    public double descarregar(){

        return 859;
    }
}
