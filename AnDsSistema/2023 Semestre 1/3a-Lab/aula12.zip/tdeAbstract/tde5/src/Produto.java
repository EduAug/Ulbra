public abstract class Produto{

    public abstract double calcularPreço();

    public abstract String exibirDetalhes();
}
