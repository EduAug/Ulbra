        <h1 class="fw-bold text-center">Home!</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dignissimos natus praesentium obcaecati eos sint ipsam dolorem alias
            incidunt ipsum ullam aspernatur saepe, aut eaque similique quas dolorum dolores? Similique quas nemo tenetur quaerat
            veniam eius ab consectetur soluta eos cum!</p>
        <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Consectetur atque consequatur sit autem esse ipsum quam facilis
            sequi praesentium similique possimus rerum vitae numquam quos delectus nemo adipisci commodi officia voluptatem, quis
            vero distinctio?</p>
        <p>Lorem ipsum dolor sit amet.</p>
        <p>UK</p>

</section>
        </div>
    </div>
</div>