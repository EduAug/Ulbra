alter table produtos
    drop column data_cadastro;