#include <stdio.h>
#include <math.h>

int main(){
	int i=1000;
		
	while(i<1500){
		if(i % 2 != 0){
		printf("%d � �mpar\n", i);
		}
		i++;
	}
	
	return 0;

}
