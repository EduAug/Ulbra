public abstract class Funcionario{

    public abstract double calcularSalario();

    public abstract String realizarTarefa();
}
