public class Carro {

    String Marca;
    String Modelo;
    int Ano;
    String Cor;

    public String acelerar(){

        return "Acelerando o carro!";
    }

    public String frear(){

        return "Freando o carro!";
    }
}
